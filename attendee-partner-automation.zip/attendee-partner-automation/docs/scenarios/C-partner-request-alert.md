# Scenario C — Partner Request Alert

![Scenario C canvas](../images/scenario-c-partner-alert.png)

| | |
|---|---|
| **Schedule** | Polling, every 10 minutes |
| **Trigger** | Airtable › Watch Records. Table `Partners`, trigger field `Created Time`, label `Organization Name`, limit 10 |
| **Filter** | (`Approval Status` = "Pending Review" **OR** `Approval Status` is empty) **AND** `Alert Sent` is not true **AND** `Import Flag` is not true |
| **Reads / writes** | `Approval Status`, `Alert Sent`, `Import Flag` |

## Modules

1. **Airtable › Watch Records** (Partners)
2. **Gmail › Send an Email** to the staff inbox
   - Subject: `New partner request needs review: {{Organization Name}}`
   - Body: Organization Name, Contact Name, Contact Email, Category, Location
3. **Airtable › Update a Record**: `Alert Sent` = true

## Notes

- **Blank status handled on purpose.** If the public request form doesn't set a default `Approval Status`, submissions arrive blank. The filter accepts blank as well as "Pending Review", and this was confirmed with a live test.
- **Import guard.** Any bulk-imported historical partners must have `Import Flag` = true. Without it, every one of them triggers an alert.
- An early version of this filter compared `Approval Status` to itself, so it was always true or always false. It was fixed by mapping the value against a literal.
