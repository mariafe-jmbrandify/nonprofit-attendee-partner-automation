# Scenario B — Post-Event Follow-Up

![Scenario B canvas](../images/scenario-b-followup.png)

| | |
|---|---|
| **Schedule** | Polling, every 10 minutes |
| **Trigger** | Airtable › Watch Records. Table **`Attendance`**, trigger field `Created Time`, label `Attendees`, limit 10 |
| **Lookup** | Airtable › Search Records on `Attendees`, formula `RECORD_ID() = "{{1.Attendees[1]}}"` |
| **Pre-router filter** | looked-up `Outreach Status` ≠ "Follow-up Sent" |
| **Reads / writes** | `Outreach Status`, `Import Flag` |

## Router

Both routes also require `Email` to exist **AND** `Import Flag` to be not true.

| Route | Condition | Actions |
|---|---|---|
| 1 · Standard | `Outreach Status` ≠ "Needs Personal Contact" | Brevo › Send an Email (template *Follow-Up*, `params.NAME` = attendee name) → Airtable › Update `Outreach Status` = "Follow-up Sent" |
| 2 · Needs Personal Contact | `Outreach Status` = "Needs Personal Contact" | Gmail › Send an Email to the staff inbox with Name, Email, Phone, Outreach Status and **Event** (mapped straight from the trigger's Attendance row) |

## Why Search Records and not Get a Record

`Attendance.Attendees` is a linked-record field, so Make receives it as an **array** of record IDs. *Get a Record* expects a single ID and failed on it. *Search Records* with `RECORD_ID() = "{{1.Attendees[1]}}"` pulls the first linked ID out and resolves it reliably.

## Why trigger on Attendance, not Attendees

A follow-up belongs to a **visit**, not a person. Triggering on the junction table means each check-in is judged on its own, and the event name is right there on the trigger record.
