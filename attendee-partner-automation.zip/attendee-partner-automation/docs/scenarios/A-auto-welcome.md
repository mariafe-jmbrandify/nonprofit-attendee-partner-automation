# Scenario A — Auto-Welcome Email

![Scenario A canvas](../images/scenario-a-welcome.png)

| | |
|---|---|
| **Schedule** | Polling, every 15 minutes |
| **Trigger** | Airtable › Watch Records. Table `Attendees`, trigger field `Created Time`, label `Email`, limit 10 |
| **Filter** | `Type` = "New Attendee" **AND** `Email` exists **AND** `Outreach Status` ≠ "Welcome Sent" |
| **Reads / writes** | `Outreach Status` |

## Modules

1. **Airtable › Watch Records** (Attendees)
2. **Brevo › Send an Email**: template *Welcome* (`BREVO_TEMPLATE_WELCOME`)
   - `To` = trigger › Email
   - `params.NAME` = trigger › First Name (falls back to Name)
   - Sender / Reply-To = the organization's static sender
3. **Airtable › Update a Record**: `Outreach Status` = "Welcome Sent"

## Why the filter uses `Type`

The first design used an Airtable *Search Records* step to check whether the person already existed. It had a structural flaw: the search could match **the record that triggered it**, so every new attendee looked like a duplicate. It was replaced with the intake form's own `Type` field (New Attendee vs. Returning Attendee), which is simpler and has no false positives.

## Error behavior

Default Make behavior. A failed module stops that run, and the failure appears in execution history.
