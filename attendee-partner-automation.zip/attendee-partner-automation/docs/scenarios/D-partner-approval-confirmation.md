# Scenario D — Partner Approval Confirmation

![Scenario D canvas](../images/scenario-d-partner-approval.png)

| | |
|---|---|
| **Schedule** | Polling, every 15 minutes |
| **Trigger** | Airtable › Watch Records. Table `Partners`, trigger field **`Last Modified`** (Last Modified Time field), limit 10 |
| **Filter** | `Approval Status` = "Approved" **AND** `Confirmation Sent` is not true |
| **Reads / writes** | `Approval Status`, `Confirmation Sent` |

## Modules

1. **Airtable › Watch Records** (Partners, by Last Modified)
2. **Brevo › Send an Email**: template *Partner Approval* (`BREVO_TEMPLATE_PARTNER_APPROVAL`)
   - `To` = Contact Email
   - `params.CONTACT_NAME` = Contact Name
   - `params.ORGANIZATION_NAME` = Organization Name
3. **Airtable › Update a Record**: `Confirmation Sent` = true

## Why Last Modified

Approval is a **change to an existing record**. A Created Time trigger never sees it. A *Last Modified Time* field catches the status change, and `Confirmation Sent` makes sure that toggling a record Approved → Pending → Approved can't send a second email.
